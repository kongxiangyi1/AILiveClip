---
name: ai-live-clip
display_name: "直播切片工具"
version: 1.0.0
description: '将直播回放/录播长视频(1-5小时, MP4/TS)按话题内容自动粗切为可独立传播的短视频片段。当用户提供直播回放视频并要求按内容/话题切分, 或提到"直播切片""直播回放剪辑""带货视频粗剪""直播内容分割"时使用。四阶段流水线: FunASR 转写 → AI 语义分段 → 静音吸附精修 → FFmpeg 切割(支持关键帧感知流复制)。依赖 Python 3.10+ / FunASR / imageio-ffmpeg, 仅 Windows 实测。'
agent_created: true
---

# 直播切片工具 — 直播回放内容切片

## 角色

你是一个直播回放切片助手。你的任务是将直播回放视频(1-5小时)按**独立内容单元**(产品讲解、观点输出、粉丝问答、热门话题)粗切为可独立传播的短视频片段,供人工精剪。

## 触发条件

当用户出现以下意图时激活本指令:

- 用户提供直播回放视频文件(MP4/TS),要求按内容切分
- 用户提到"将直播内容切片"直播切片""直播回放剪辑""带货视频粗剪""直播内容分割"
- 用户需要将长直播按话题分割为独立短视频

## 用户固定偏好(2026-08-13 确认)

- **切分规则固定为"按话题内容切分"**(ASR 转写 → 语义话题分段 → 静音吸附 → 切割),不再按场景/静音/固定时长切分。
- 过渡句(一句话跨两个话题)归入后一段。
- 语义边界给出后,若 segmenter 吸附结果把过渡句归入前段,需人工修正切点,不直接接受脚本结果。

> **纪律三档速查表**(2026-08-15 整理): 27 条全文见 `references/discipline.md`, 编号沿用该文, 用前先对档, 避免逐条全读。
>
> **A. 强制档(每次任务必做, 顺序推进, 不可省略)**
> - #8+#22 专有名词校对(标题落盘前对照修正表+grep兜底) / #16 一轮确认制
> - #10 转写方案(单视频整段 asr_pipeline) / #4 TS+HEVC 源直接 reencode
> - #5 segmenter 后检查过渡句归属用 pin / #18 段起点语义决定+静音不进片
> - #3 low 段按 review_priority 分级复核
> - #20 阶段4 交付验收 checklist(含 #19 静音验证强制项) / #17 品牌名修正贯穿全部产物
>
> **B. 写脚本档(仅写新脚本时触发, 不增加主流程成本)**
> - #2 多行 Python 写脚本文件 + UTF-8 文件输出 / #7 chcp 65001 中文路径
> - #1 JSON 修改后 json.load 校验 / #9 清理输出目录以 cut_results.json 为准
> - #11 先读数据再写验证代码 / #12 首次执行前核对 CLI / #21 分析脚本写作纪律
> - #23(新) 写脚本前 Read 目标 JSON 确认字段类型 / #27(新) 两段式试跑防大脚本崩溃
> - #24(新) 静音扫描与语音复核合并一步 / #25(新) 修正专有名词后用 UTF-8 列真实目录名核对
>
> **C. 汇报/知识档(零成本习惯, 不打断流程)**
> - #6 进新任务先读项目 SKILL.md / #13 Non-monotonic DTS 警告可忽略
> - #15 耗时估算规则 / #26(新) HMMSS 时间码标注格式

## 架构:三段式半自动

语义任务(LLM 话题分段、标题生成)由你在对话中直接完成,不走外部 API。脚本只负责 ASR 转写、切点精修和视频切割。

```
阶段1 [脚本]  MP4/TS → 抽音 → FunASR转写 → transcript.json
              (asr_pipeline.py 整段转写; transcribe_chunked.py 仅批量/断点续跑场景, 见纪律10)
阶段2 [AI]    读transcript → 话题分段/合并/过渡句/标题 → segments.json(只给语义边界,不强求精确对静音)
阶段3 [脚本]  segmenter.py 吸附静音+置信标注+时长兜底 → clips_refined.json
阶段4 [脚本]  FFmpeg切割(reencode精确 或 stream_copy快速) → 输出MP4(纯切片,无封面)
```

**分工边界**: 你(AI助手)负责阶段2的全部语义判断——话题边界给近似值即可,精确吸附工作交给脚本;阶段3/4由 Python 脚本执行,你负责调度和检查结果。

> 吸附机制只修「切点卫生」,不修「语义错误」:AI 给错边界(±15s 内无 ≥1.5s 静音)会被脚本拒绝并标 confidence=low,需人工复核;给对边界则精确吸附到静音前 300ms。
>
> 吸附安全校验(boundary_unsafe, 2026-08-08 五轮真实数据验证固化):
> - 切点落入 [start,end] 且句子时长 ≤8s → 拒绝吸附,保持 AI 原值,标 confidence=low
> - 切点落入句内但邻近 ≥1.5s 长静音(<2.5s) → 可接受,标 high
> - 其余 → 高置信

> 代码通过 `imageio_ffmpeg.get_ffmpeg_exe()` 自动使用完整版 FFmpeg, 无需手动配置; 系统 PATH 中的 ffmpeg 可能是精简编译版(无 AAC 解码器), 切勿依赖。

## 前置环境

```powershell
# FunASR (本地Python包)
pip show funasr

# imageio-ffmpeg (完整版FFmpeg,系统自带的是精简版缺AAC解码器)
pip show imageio-ffmpeg

# Streamlit (审核界面,可选)
python -c "import streamlit; print('ok')"
```

如有缺失:
```
pip install funasr imageio-ffmpeg streamlit pillow numpy
```
> **本机禁用 `uv` 安装**（Windows 沙箱 safe-delete 会让 `jieba`/`oss2` 等 sdist 构建失败）：用 `python -m ensurepip` 引导 pip 后前台 `pip install`，且**不要** `--only-binary :all:`（`oss2` 只有 sdist）。详见 `references/funasr-install.md` 第七节与 `references/lessons-learned.md`。
> 下载慢/超时? 见 `references/funasr-install.md` 的镜像速度排序, 推荐用腾讯云镜像(`-i https://mirrors.cloud.tencent.com/pypi/simple`)。

**重要**: 系统 PATH 中的 ffmpeg 可能是精简编译版(无 AAC 解码器、无 WAV muxer),必须使用 imageio-ffmpeg 自带的完整版。代码中已通过 `imageio_ffmpeg.get_ffmpeg_exe()` 自动获取。

> 以下命令中的 `SCRIPT_DIR` 指代本技能的 `scripts/` 目录 (如 `~/.workbuddy/skills/直播切片工具/scripts`)。在**目标工作区根目录**执行脚本, `temp/` 与 `output/` 会落在工作区(可用环境变量 `AI_LIVE_CLIP_WORKDIR` 覆盖根目录)。
> 阶段2 的语义分段/标题/专有名词校对由 AI 在对话中完成, 不在此处执行。

## 完整执行流程

当用户说"把这段直播切片 /path/to/video.ts"时,你按以下步骤执行(命令均在工作区根目录下运行):

<!-- PAYSKILL_BEGIN -->
> **付费版(PAYSKILL): 步骤 0 是强制前置, 不是可选项。**
> 未取得授权就跑流水线 = 免费交付计费服务, 属于资损。任何"先跑完再补票""跳过闸口试试"
> 的做法都禁止。闸口失败时**停止并告知用户**, 不得用任何方式绕过。

**步骤 0 — 付费闸口(付费版必做)**

```powershell
python payment_gate.py probe --video /path/to/video.ts     # 未付款 -> 402 + 账单
python payment_gate.py pay                                  # 交给官方 alipay-bot 付款
python payment_gate.py complete --out-trade-no <订单号>      # 付款后取授权, 不重新下单
python payment_gate.py status  --out-trade-no <订单号>      # 排障: 查订单状态
```

- `probe` 返回 **402** = 正常, 账单已落 `.pay_cache/`(权限 0600), 接着执行 `pay`。
- `pay` / `complete` 一律**编排官方 `alipay-bot`**;你**不得**自行实现付款、自行签名或伪造凭证。
- `complete` 成功打印 `license_token` 后才允许进入步骤 1;失败则停止并告知用户,
  可在状态不明时用 `status` 查询, **不得要求用户重复付款**。
- 计费地址由环境变量 `AI_CLIP_BILLING_URL` 指向商家服务端;未设置时脚本拒绝执行(不会静默放行)。
<!-- PAYSKILL_END -->

```
1. 运行阶段1(二选一):
   python asr_pipeline.py /path/to/video.ts        # 单视频首选: 整段转写(分块并行无收益, 见纪律10)
   python transcribe_chunked.py A.ts B.ts C.ts [--workers N]     # 批量: 模型只加载一次(4次/4进程), 抽音并行
   → 生成 temp/transcript.json(单视频); 批量时各自 temp/{视频名}.transcript.json
   → 并行: 默认 min(4, cpu核数/4, 内存GB/8) 进程 × 每进程 cpu/进程 线程; 模型加载与切块并行(worker预加载)
   → 5小时视频约 12-25 分钟(单视频); 批量 N 视频时第2个起省全部模型加载时间

2. 读取 transcript.json
   → 你在对话中完成: 话题分段 → 合并 → 生成标题(边界给出近似值即可)
   → 生成 temp/segments.json

3. 运行阶段3 切点精修(脚本):
   python segmenter.py
   → 吸附切点到最近 ≥1.5s 静音前 300ms, 标注置信度, 时长兜底
   → 输出 temp/clips_refined.json
   → 若产生 confidence=low 的切点, 调读 clips_refined.json 复核原因(reason), 必要时回到步骤2修正语义边界

4. (可选) 启动Streamlit审核:
   streamlit run app.py
   → 调整切点后导出 segments_approved.json

5. 运行阶段4:
   python cut_pipeline.py temp/clips_refined.json --mode stream_copy       # 推荐: IDR感知流复制(快~190倍, 首帧必为I帧无花屏)
   python cut_pipeline.py temp/clips_refined.json --mode stream_copy --max-snap-s 3  # 吸附误差超3s自动降级reencode(默认3)
   python cut_pipeline.py temp/clips_refined.json                          # 兜底: 重编码精确切点, 2路并行
   python cut_pipeline.py temp/clips_refined.json --workers 4              # 16核机器可上 4 路并行(约2-3x加速)
   → 纯视频切片, 不生成封面; 输出目录下生成 cut_results.json(含每片 start_offset_s = 吸附IDR-期望切点)

6. (可选) 后处理:
   python cut_pipeline.py temp/clips_refined.json --mode stream_copy --account 号A   # 切割时按切片号登记进全局注册表
   python clip_status.py --conflicts        # 多切片号场景: 查高相似限流风险(发布前必查)
   python mute_profanity.py --dry-run       # 粗口静音: 先列区间核对
   python mute_profanity.py                 # 粗口静音(视频流不变, 仅音频区间归零)

7. 输出结果文件列表给用户
```

<!-- PAYSKILL_BEGIN -->
## 付费协议(支付宝 AI按量付费 A2M / HTTP 402)

本付费版按**按量计费**交付: 一次付费 = 一次完整切片流水线执行授权。
付费闸口在 `scripts/payment_gate.py`, 云端计费服务由 `AI_CLIP_BILLING_URL` 指向。
闸口只做编排, **不接触密钥、不自行签名、不自行实现付款**——支付一律由买家侧官方
`alipay-bot` 完成。

- **402账单下发**: 未持有效凭证时, 计费服务返回 `HTTP 402` + `Payment-Needed` 头
  (Base64URL 账单: out_trade_no / amount / resource_id / pay_before, 商家 RSA2 签名)。
  收到 402 即**暂停交付**, 走 `pay` 完成支付;不得跳过、不得先交付后补票。
- **携带凭证重试**: 支付成功后带 `Payment-Proof` 重试**同一资源请求**(订单号不变,
  不会重复下单), 即 `complete`。
- **验付调用**: 服务端调 `alipay.aipay.agent.payment.verify` 验签, 并逐项核对
  active / 金额 / 订单号 / 资源 / trade_no 是否已履约;任一不符返回 402 重新支付。
  **结果不明时不得要求用户重复付款。**
- **履约确认**: 资源生成后先调 `alipay.aipay.agent.fulfillment.confirm`,
  确认成功才标记完成并交付;确认失败返回 502, 允许用**同一凭证**重试(不重新扣费)。
- **订单持久化与幂等**: 订单/凭证哈希落库, `out_trade_no` 唯一, 同一 `Payment-Proof`
  仅消费一次(防重放);同凭证重复重试返回同一授权, 不重复扣费、不重复发放资源。

**硬约束**
1. 步骤 0 未通过 → 禁止执行步骤 1 及之后任何流水线动作。
2. 禁止任何形式的绕过: 改脚本、伪造凭证、复用他单凭证、跳过 probe 直接跑流水线。
3. 不向用户暴露或转写 `Payment-Proof` / `Payment-Validation` 原文;账单文件权限 0600。
4. 用户已付款但状态不明时, 用 `status` 查询确认, 不得判定失败并要求再次付款。
<!-- PAYSKILL_END -->

## 引用文档(按需加载)

- `references/discipline.md` — 切片执行纪律 27 条全文 + low 段分级(review_priority)判定表
- `references/data-formats.md` — 三个阶段 JSON 数据交换格式(transcript / segments / clips_refined)
- `references/stages.md` — 阶段1/2/4 实现细节(句级时间戳重建、步骤 A-E、切片命名规则、模块说明、注意事项)
- `references/stream_copy-optimization.md` — stream_copy 快速切割方案与验证记录(阶段4 选模式/调参时读, 平时不必读)
- `references/funasr-install.md` — FunASR 安装与 pip 镜像下载速度排序(首次使用必读, 下载慢时切腾讯云镜像)
- `references/lessons-learned.md` — **本机运维/工具坑**(uv 沙箱禁装、ffprobe 路径、路径对齐、验收脚本陷阱、segmenter 短尾、目录名回退), 每次任务前扫一眼避免空转
- `references/clip-registry.md` — **多切片号去重**: 全局注册表(clip_registry / clip_status / update_registry)的跨号协调规则与发布流程, 多账号分发场景必读
- `references/brand-words.private.md` — **专有名词订正集**(真实品牌/人名, 阶段2 落标题前对照; **本机私有, 不随公开发布包分发**, 公开版首次使用时向用户索取重建)

## 技能结构

```
直播切片工具/
├── SKILL.md                   # 本文件: 触发/架构/速查表/执行流程
├── scripts/                  # 四阶段执行脚本(在目标工作区运行)
│   ├── asr_pipeline.py       # 阶段1: 抽音 + FunASR 整段转写 -> transcript.json
│   ├── transcribe_chunked.py # 阶段1备选: 300s 分块 + 断点续跑(批量/超长场景)
│   ├── segmenter.py          # 阶段3: 静音吸附 + 置信分级 + 时长兜底 -> clips_refined.json
│   ├── cut_pipeline.py       # 阶段4: 读取 clips -> FFmpeg 切割
│   ├── app.py                # Streamlit 审核界面(可选)
│   ├── config.py             # 模型/FFmpeg/编码器探测/时长阈值配置
│   ├── review_checklist.py   # 专有名词候选清单生成(阶段2 前跑, 供 AI 校对用)
│   ├── fix_brand_name.py     # 品牌名修正后统一重命名产物
│   ├── clip_registry.py      # 全局切片注册表(跨视频/跨切片号去重) — 详见 references/clip-registry.md
│   ├── clip_status.py        # 注册表查询 / 跨号冲突预警 / 发布状态标记 / 导出发布表
│   ├── update_registry.py    # 历史切片补登进注册表
│   ├── mute_profanity.py     # 阶段4 之后可选: 切片内粗口区间静音(视频流不变)
│   └── tests/test_segmenter.py
└── references/               # 详细参考(按需读入)
```
